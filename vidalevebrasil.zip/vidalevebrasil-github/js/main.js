// Main JavaScript for VidaLeve Brasil Website

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initMobileMenu();
    initStickyHeader();
    initBackToTop();
    initFaqAccordion();
    initTestimonialSlider();
    initContactForm();
    initNewsletterForm();
    
    // Initialize product-specific components if on product page
    if (document.querySelector('.product-landing')) {
        initCountdown();
        initStockCounter();
    }
});

// Mobile Menu Toggle
function initMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuBtn && mainNav) {
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            
            // Toggle hamburger icon animation
            const spans = this.querySelectorAll('span');
            if (mainNav.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.mobile-menu-btn') && !event.target.closest('.main-nav')) {
                mainNav.classList.remove('active');
                const spans = mobileMenuBtn.querySelectorAll('span');
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
        
        // Close menu when clicking on a nav link
        const navLinks = mainNav.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                mainNav.classList.remove('active');
                const spans = mobileMenuBtn.querySelectorAll('span');
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            });
        });
    }
}

// Sticky Header
function initStickyHeader() {
    const header = document.querySelector('.header');
    
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

// Back to Top Button
function initBackToTop() {
    const backToTopBtn = document.querySelector('.back-to-top');
    
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                backToTopBtn.classList.add('active');
            } else {
                backToTopBtn.classList.remove('active');
            }
        });
        
        backToTopBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// FAQ Accordion
function initFaqAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    if (faqItems.length > 0) {
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            
            question.addEventListener('click', function() {
                // Close all other items
                faqItems.forEach(otherItem => {
                    if (otherItem !== item && otherItem.classList.contains('active')) {
                        otherItem.classList.remove('active');
                    }
                });
                
                // Toggle current item
                item.classList.toggle('active');
            });
        });
        
        // Open first FAQ item by default
        faqItems[0].classList.add('active');
    }
}

// Testimonial Slider
function initTestimonialSlider() {
    const slider = document.querySelector('.testimonials-slider');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const testimonials = document.querySelectorAll('.testimonial-item');
    
    if (slider && testimonials.length > 0) {
        let currentIndex = 0;
        
        // Hide all testimonials except the first one
        testimonials.forEach((testimonial, index) => {
            if (index !== 0) {
                testimonial.style.display = 'none';
            }
        });
        
        // Previous button click
        if (prevBtn) {
            prevBtn.addEventListener('click', function() {
                testimonials[currentIndex].style.display = 'none';
                currentIndex = (currentIndex - 1 + testimonials.length) % testimonials.length;
                testimonials[currentIndex].style.display = 'flex';
            });
        }
        
        // Next button click
        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                testimonials[currentIndex].style.display = 'none';
                currentIndex = (currentIndex + 1) % testimonials.length;
                testimonials[currentIndex].style.display = 'flex';
            });
        }
        
        // Auto slide every 5 seconds
        setInterval(function() {
            if (nextBtn) {
                nextBtn.click();
            }
        }, 5000);
    }
}

// Contact Form
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            
            // Simple validation
            if (!name || !email || !subject || !message) {
                alert('Por favor, preencha todos os campos.');
                return;
            }
            
            // Simulate form submission
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            submitBtn.innerHTML = 'Enviando...';
            submitBtn.disabled = true;
            
            // Simulate API call
            setTimeout(function() {
                // Reset form
                contactForm.reset();
                
                // Show success message
                alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
                
                // Reset button
                submitBtn.innerHTML = 'Enviar Mensagem';
                submitBtn.disabled = false;
            }, 1500);
        });
    }
}

// Newsletter Form
function initNewsletterForm() {
    const newsletterForm = document.getElementById('newsletterForm');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get email value
            const email = newsletterForm.querySelector('input[type="email"]').value;
            
            // Simple validation
            if (!email) {
                alert('Por favor, informe seu email.');
                return;
            }
            
            // Simulate form submission
            const submitBtn = newsletterForm.querySelector('button[type="submit"]');
            submitBtn.innerHTML = 'Inscrevendo...';
            submitBtn.disabled = true;
            
            // Simulate API call
            setTimeout(function() {
                // Reset form
                newsletterForm.reset();
                
                // Show success message
                alert('Inscrição realizada com sucesso! Você receberá nossas novidades em breve.');
                
                // Reset button
                submitBtn.innerHTML = 'Inscrever-se';
                submitBtn.disabled = false;
                
                // Track conversion
                trackConversion('newsletter_signup');
            }, 1500);
        });
    }
}

// Countdown Timer (for product pages)
function initCountdown() {
    const countdownContainer = document.querySelector('.countdown');
    
    if (countdownContainer) {
        // Set countdown for 48 hours from now
        const endTime = new Date();
        endTime.setHours(endTime.getHours() + 48);
        
        function updateCountdown() {
            const now = new Date();
            const diff = endTime - now;
            
            if (diff <= 0) {
                // Reset countdown to another 48 hours when it reaches zero
                endTime.setHours(endTime.getHours() + 48);
                updateCountdown();
                return;
            }
            
            // Calculate hours, minutes, seconds
            const hours = Math.floor(diff / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);
            
            // Update DOM
            document.querySelector('.countdown-hours').textContent = hours.toString().padStart(2, '0');
            document.querySelector('.countdown-minutes').textContent = minutes.toString().padStart(2, '0');
            document.querySelector('.countdown-seconds').textContent = seconds.toString().padStart(2, '0');
        }
        
        // Initial update
        updateCountdown();
        
        // Update every second
        setInterval(updateCountdown, 1000);
    }
}

// Stock Counter (for product pages)
function initStockCounter() {
    const stockCounter = document.querySelector('.stock-counter');
    
    if (stockCounter) {
        // Get stock progress bar
        const stockProgress = document.querySelector('.stock-progress');
        const stockText = document.querySelector('.stock-text');
        
        // Set initial stock (random between 5-15)
        let stock = Math.floor(Math.random() * 11) + 5;
        updateStockDisplay();
        
        // Update stock display
        function updateStockDisplay() {
            stockText.textContent = `Apenas ${stock} unidades disponíveis`;
            stockProgress.style.width = `${(stock / 100) * 100}%`;
        }
        
        // Randomly decrease stock every 30-120 seconds
        function decreaseStock() {
            // Only decrease if stock > 3 (to maintain urgency)
            if (stock > 3) {
                stock -= 1;
                updateStockDisplay();
                
                // Show notification
                showStockNotification();
            }
            
            // Set next decrease time (random between 30-120 seconds)
            const nextDecrease = Math.floor(Math.random() * 91) + 30;
            setTimeout(decreaseStock, nextDecrease * 1000);
        }
        
        // Show stock notification
        function showStockNotification() {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = 'stock-notification';
            notification.innerHTML = `
                <div class="stock-notification-content">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Alguém acabou de comprar este produto! Apenas ${stock} unidades restantes.</p>
                </div>
            `;
            
            // Add styles
            notification.style.position = 'fixed';
            notification.style.bottom = '20px';
            notification.style.right = '20px';
            notification.style.backgroundColor = 'rgba(231, 76, 60, 0.9)';
            notification.style.color = 'white';
            notification.style.padding = '15px';
            notification.style.borderRadius = '5px';
            notification.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
            notification.style.zIndex = '9999';
            notification.style.transform = 'translateX(120%)';
            notification.style.transition = 'transform 0.3s ease';
            
            // Add to DOM
            document.body.appendChild(notification);
            
            // Show notification
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 100);
            
            // Remove notification after 5 seconds
            setTimeout(() => {
                notification.style.transform = 'translateX(120%)';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 5000);
        }
        
        // Start decreasing stock after 60 seconds
        setTimeout(decreaseStock, 60000);
    }
}

// Smooth Scroll for Anchor Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            const headerHeight = document.querySelector('.header').offsetHeight;
            const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - headerHeight;
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// Track Conversion (for analytics)
function trackConversion(type, value = 0) {
    // This would normally send data to an analytics service
    console.log(`Conversion tracked: ${type}, Value: ${value}`);
    
    // Store in localStorage for demonstration
    const conversions = JSON.parse(localStorage.getItem('conversions') || '[]');
    conversions.push({
        type,
        value,
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('conversions', JSON.stringify(conversions));
}

// Add to Cart Function (for product pages)
function addToCart(productId, productName, price) {
    // This would normally add the product to a cart system
    console.log(`Product added to cart: ${productName} (${productId}), Price: ${price}`);
    
    // Show confirmation message
    alert(`${productName} adicionado ao carrinho!`);
    
    // Track conversion
    trackConversion('add_to_cart', price);
    
    // Redirect to checkout (simulated)
    setTimeout(() => {
        window.location.href = `checkout.html?product=${productId}`;
    }, 500);
}

// Exit Intent Popup
function initExitIntentPopup() {
    // Only show once per session
    if (sessionStorage.getItem('exitPopupShown')) return;
    
    // Create popup element
    const popup = document.createElement('div');
    popup.className = 'exit-popup';
    popup.innerHTML = `
        <div class="exit-popup-content">
            <span class="exit-popup-close">&times;</span>
            <h3>Espere! Não vá embora ainda...</h3>
            <p>Receba 10% de desconto no seu primeiro pedido!</p>
            <form id="exitPopupForm" class="exit-popup-form">
                <input type="email" placeholder="Seu melhor email" required>
                <button type="submit" class="btn btn-primary">Quero meu desconto!</button>
            </form>
        </div>
    `;
    
    // Add styles
    popup.style.position = 'fixed';
    popup.style.top = '0';
    popup.style.left = '0';
    popup.style.width = '100%';
    popup.style.height = '100%';
    popup.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    popup.style.display = 'flex';
    popup.style.alignItems = 'center';
    popup.style.justifyContent = 'center';
    popup.style.zIndex = '9999';
    popup.style.opacity = '0';
    popup.style.visibility = 'hidden';
    popup.style.transition = 'opacity 0.3s ease, visibility 0.3s ease';
    
    // Add to DOM
    document.body.appendChild(popup);
    
    // Close button functionality
    const closeBtn = popup.querySelector('.exit-popup-close');
    closeBtn.style.position = 'absolute';
    closeBtn.style.top = '10px';
    closeBtn.style.right = '10px';
    closeBtn.style.fontSize = '24px';
    closeBtn.style.cursor = 'pointer';
    
    closeBtn.addEventListener('click', function() {
        popup.style.opacity = '0';
        popup.style.visibility = 'hidden';
    });
    
    // Form submission
    const form = popup.querySelector('#exitPopupForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get email
        const email = form.querySelector('input[type="email"]').value;
        
        // Simple validation
        if (!email) return;
        
        // Simulate form submission
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.innerHTML = 'Enviando...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(function() {
            // Reset form
            form.reset();
            
            // Update popup content
            popup.querySelector('.exit-popup-content').innerHTML = `
                <h3>Parabéns!</h3>
                <p>Seu cupom de desconto foi enviado para seu email.</p>
                <p>Use o código <strong>VIDALEVE10</strong> no checkout.</p>
                <button class="btn btn-primary exit-popup-close-btn">Continuar</button>
            `;
            
            // Add event listener to new close button
            popup.querySelector('.exit-popup-close-btn').addEventListener('click', function() {
                popup.style.opacity = '0';
                popup.style.visibility = 'hidden';
            });
            
            // Track conversion
            trackConversion('exit_popup_signup');
        }, 1500);
    });
    
    // Show popup on exit intent
    document.addEventListener('mouseleave', function(e) {
        // Only trigger if mouse leaves through top of the page
        if (e.clientY < 0 && !sessionStorage.getItem('exitPopupShown')) {
            popup.style.opacity = '1';
            popup.style.visibility = 'visible';
            
            // Mark as shown
            sessionStorage.setItem('exitPopupShown', 'true');
        }
    });
}

// Initialize exit intent popup after 5 seconds
setTimeout(initExitIntentPopup, 5000);

// Add page-specific initialization
if (document.querySelector('.product-landing')) {
    // Initialize product page specific features
    document.addEventListener('DOMContentLoaded', function() {
        // Add click event to CTA buttons
        const ctaButtons = document.querySelectorAll('.product-cta-btn');
        ctaButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Get product info from data attributes
                const productId = this.getAttribute('data-product-id');
                const productName = this.getAttribute('data-product-name');
                const price = parseFloat(this.getAttribute('data-price'));
                
                // Add to cart
                addToCart(productId, productName, price);
            });
        });
    });
}
